#*******************************************************************#
#******************** Matemáticas Especiales ***********************#
#**** Método Numérico para la resolución de Ecuaciones Lineales ****#
#********Elaborado por Juan Carlos Vega y Diego Robledo*************#
#*******************************************************************#

# Librerias
import numpy as np

## Se definen las funciones que permitirán resolver las ecuaciones lineales

#1.  Definición de Función para Gauss Simple
def gauss_simple(A, b):
    # Declaración de las matrices
    A = A.astype(float)
    b = b.astype(float)
    n = len(b)
    # concatenación de matrices
    Ab = np.hstack([A, b.reshape(-1, 1)])
    #iteraciones por filas y columnas
    for i in range(n-1):
        max_row = np.argmax(np.abs(Ab[i:n, i])) + i
        Ab[[i, max_row], :] = Ab[[max_row, i], :]

        for j in range(i+1, n):
            m = Ab[j, i] / Ab[i, i]
            Ab[j, :] -= m * Ab[i, :]
    #se crea un vector de ceros para guardar las soluciones
    x = np.zeros(n)
    # se realizan los productos punto de las matrices y se llena el vector x con las soluciones
    for i in range(n-1, -1, -1):
        x[i] = (Ab[i, -1] - np.dot(Ab[i, i+1:n], x[i+1:n])) / Ab[i, i]

    return x



#############
# Definición de Función para Gauss Seidel
def gauss_seidel(A, b, tol, max_iter):
    A = A.astype(float)
    b = b.astype(float)
    n = len(b)
    x = np.zeros(n)
    iter_count = 0
    # iteraciones por fila y columna
    for k in range(max_iter):
        x_new = np.copy(x)
        # iteraciones por fila y columna
        for i in range(n):
            s1 = np.dot(A[i, :i], x_new[:i])
            s2 = np.dot(A[i, i+1:], x[i+1:])
            x_new[i] = (b[i] - s1 - s2) / A[i, i]
        # validación de la diagonal contra el valor de la tolerancia de la diferencia  
        if np.linalg.norm(x_new - x) < tol:
            return x_new
        x = x_new
        iter_count += 1

    return x

###################
# EJEMPLOS

# 1. Ejemplo de sistemas de ecuaciones 4x4 para método Gauss-Simple
A1 = np.array([[1,2,-1,3], [2,0,2,-1], [-1,1,1,-1],[3,3,-1,2]]) #Se define los valores de la matriz de coeficientes
b1 = np.array([-8,13,8,-1]) #Coeficientes independientes
solucion_GaussSimple = gauss_simple(A1, b1)
print("Resultados del método Gauss-Simple:\n",solucion_GaussSimple)

#############
# Parametros para iteraciones de Gauss-Seidel
tolerancia=0.01
iteramax = 100

# 2. Ejemplo de sistemas de ecuaciones 4x4 para método Gauss-Seidel
A2 = np.array([[3, -4, 5, -7], [1, 2, -4, 5], [2, -4, 5, -41],[3, -1, 7,5]]) #Se define los valores de la matriz de coeficientes
b2 = np.array([19, 31, 21, 10]) #Coeficientes independientes
solucion_GaussSeidel = gauss_seidel(A2, b2,tol=tolerancia,max_iter=iteramax)
print("Resultados del método Gauss-Seidel:\n",solucion_GaussSeidel)

